import java.util.ArrayList;
import java.util.Arrays;

public class MaquinaSoldar {
    //Atributos
    private String marca;
    private String modelo;
    private int potencia;
    private ArrayList<String> metalesPermitidos;

    //Constructor
    public MaquinaSoldar(String marca, String modelo, int potencia, String[] metalesPermitidos) {
        this.marca = marca;
        this.modelo = modelo;
        this.potencia = potencia;
        this.metalesPermitidos = new ArrayList<>(Arrays.asList(metalesPermitidos));
    }

    //Setters
    public void soldar(String metal) {
        if (metalesPermitidos.contains(metal)){
            System.out.println("La maquina de soldar marca: " + marca + ", modelo: " + modelo +
                    " puede soldar " + metal + ".");
        } else{
            System.out.println("La maquina de soldar marca: " + marca + ", modelo: " + modelo +
                    " no puede soldar " + metal + ".");
        }
    }
}
